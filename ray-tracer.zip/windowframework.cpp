/*
 * File: windowframework.cpp
 * Authors: Alexander Epp (1487716) and Mitchell Epp (1498821)
 * Project: CMPUT274 Final Project
 * Description: Contains implementations of WindowFramework methods
 */

#include "windowframework.h"

WindowFramework::WindowFramework()
{
}
WindowFramework::~WindowFramework()
{
}
